                     
  1)	What is the output of following code
            var arr = [12,45,67,89];
            arr[100]  = [99];
            console.log(arr.length);
2)	Write the Six Selector in JavaScript to select the DOM elements and explain each one of them
        DOM selectors, as the name suggests is  used to select HTML elements within a document using JavaScript. there are 5 ways in which you can select elements in a DOM using selectors
              
         I.	getElementById() :- this selector is based on the Id name and this seems to be similar to Tag name & class name selector but there’s a difference in how many elements this selector selects. In all the selectors, a list of all matching elements is returned .But this selector returns only the first matched element while ignoring the remaining.
                     II.	
                     III.	 getElementByClassName() :- This method returns all the elements that matches the specified Class name.
                     IV.	getElementByTagName() :- This method returns all the elements that matches the specified Tag Name.
                     V.	QuarySelector() :- This one returns the first elements that matches the specified CSS selector in the document.
                     VI.	QuarySelectorAll() :- This method returns all the elements that match specified CSS selector in the document.
                     
                     
                     
                     
                     
    3)	What is difference between indexOf and search methods?
                     •	IndexOf() and search() are same but there is a difference.
                     •	indexOf method does is that it returns the position(index) of the first Occurrence of the specified value. If that value is not found then it returns -1.
                     •	indexOf and Search method findsa string for the specified value,and same as indexOf,it returns the position of the value in the string.Search method , search value can either be stringor it can be a regular expression. Is that value is not found then it returns -1.
                      
                     
                           ___________________________________________________________________________
                     
                     4)	Write a Program to print 1-100 Fibonacci numbers
                     Input : 100
                     Output : 1,3,5,8,13,……..89
                     let fibonacci = [1,1];
                           function listFibonacci(num) {
                             for (let i = 1; i < num; i++) {
                                 fibonacci.push(fibonacci[i] + fibonacci[i - 1]);
                             }
                             console.log(fibonacci);
                         }
                         
                         listFibonacci(10);
                     
                     Input : 5
                     Output 1,3,5
                     let fibonacci = [1,1];
                         
                         function listFibonacci(num) {
                         // starting at array index 1, and push current index + previous index to the array
                             for (let i = 1; i < num; i++) {
                                 fibonacci.push(fibonacci[i] + fibonacci[i - 1]);
                             }
                             console.log(fibonacci);
                         }
                         
                         listFibonacci(4);
                     
                     5)	Write a JavaScript program to convert temperatures to and from Celsius, Fahrenheit.
                     Sample I/O
                     Input :  0 
                     Output :  32 Fahrenheit 
                     
                     Input : 5
                     Output 41 Fahrenheit
                     
                     
                     6)	Write a program to  find the two number in which there  sum should be  equal to 10  of an array
                     Sample I/O
                     Input let array = [2,3,5, 7,9,0];
                     Output = 3,7;
                     
                     7)	What will be the output of the following JavaScript code?
                     var a = 10;
                     do {
                           a += 1;
                           console.log(a);
                     } while (a < 5);
                     Output:11
                     8)	What is the Difference between innerText and innerHTML 
                     innerText returns all text contained by an element and all its child elements. It ignores the spaces. innerHTML returns all text, including html tags, that is contained by an element. It considers the spaces.
                                         
                     9)	Consider 
                     let arr  = [23,34,45,56,67,77,88,45];
                     let arr2 = [23,34,45,56,67,77,88,45];
                     if(arr=== arr2){
                     console.log(‘True’);
                     }
                     else {
                     console.log(‘False’);
                     }
                     A)	false
                     _______________________________________________________________________
                     
                     10)	What is DOM, explain DOM Briefly and what are the things we can do using DOM Methods
                     A)	DOM defines a standard for accessing documents: DOM  is a platform and that allows programs and scripts to dynamically access and update the content, structure and style of a document.  
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     