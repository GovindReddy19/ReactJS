// function welcomeMessage(){
//     document.write("<h1>Welcome to AIT</h1>")
//     document.write("<p>The function name. Can be omitted, in which case the function becomes known as an anonymous function.</p>")
// }
//     welcomeMessage();

// function WelcomePara(){
//     document.write("<p>The function name. Can be omitted, in which case the function becomes known as an anonymous function.</p>")
// } 
//     WelcomePara();

// function WelcomeImg(){
//     document.write('<img src="./images/Agra.jpg"/')
// }    
//     WelcomeImg();

// var userId = 123;
// var password = "ait@123";

// function loginUser(){
//       if(userId == "123" && typeof userId =="number" && password =="ait@123"){
//         //   alert("Welcome to AIT");
//        } else{
//         //    alert("Invalid Credential") 
          
//       }  
// }
//     loginUser();

// function culReturn(x,y){
//     var result = x*y;
//     return result;
// }
//     var output = culReturn(20,30)
//     console.log(output)


// function myData(some){
//     document.getElementById("demo").innerHTML = some;
//  }
//  function myCal(nam1, nam2){
//      let sum = num1 + num2;
//      myData(sum);
//  }
//     mycal(2,3);

// var hi;
// hi = () => "Arrow functions";
// document.getElementById("demo").innerHTML = hi();

