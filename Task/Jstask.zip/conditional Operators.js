// var number=4;
//     if(number%2==0){}
//         console.log(number+"is an Number");
//      else
//         console.log(number+"is an Odd Number");
// }     


// program to check if the number is even or odd
// take input from the user
// var number = 6;

// //check if the number is even
// if(number % 2 == 0) {
//     console.log("The number is even.");
// }

// // if the number is odd
// else {
//      console.log("The number is odd.");
//  }

// var age = 19;

// if(age<3){
//     console.log('infant');
// }
// elseif(age>3 && age<=12) 
// {
//     console.log('child');
// }
// elseif(age>12 && age<=19) 
// {
//     console.log('teen');
// }
// elseif(age>19 && age<40) 
// {
//     console.log('adult');
// }
// else {
//     console.log('old age');
// }

// var i, j;
//   //outer loop
//   for(i=1; i <= 5; i++)
//    {
//    //inner loop
//     for(j=1; j<=i; j++)
//    {
//      document.write('*');
//     }
//      document.write('<br/>');
//    }

var fruits = [‘apple’,’mango’,’bannana’,’pineapple’]
{
    console.log(fruits.length)
}
