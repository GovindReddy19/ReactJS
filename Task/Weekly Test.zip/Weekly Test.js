// let i = 0;
  // For(let j=i;j>=0;j--){
  // If(i>3) break;
  // Console.log(i);
  // i++;
  // }
//   13) Write 5 different array methods with example  
// var cars =['Oodi','Ferrari','BMW','Toofan'];
// console.log(cars.indexOf('BOLERO'));
// console.log(cars.join('-'))
// cars.push('Hyundai')
// console.log(cars)
// cars.pop('Hyundai')
// console.log(cars)
// cars.unshift('Hyundai')
// console.log(cars)
// cars.shift('Hyundai')
// console.log(cars)
// var reverseElements=cars.reverse();
// console.log(reverseElements)

// 17) Write a program to find the given number is palindrome or not ?
// function validatePalin(str){
// const len = string.length;
// for (let i=0;i<len/2;i++){
//    if(string[i]!==string[len-1-i]){
//      alert('it is not palindrome');
//    }
// }
// alert('it is a palindrome');
// }

// const string = prompt('enter a string or number');

// const value = validatepalin(string);
// console.log(value);

// let result = a&&b ;
// console.log(result[a]);